import { motion } from "framer-motion";
import { ArrowRight, Mail, MapPin, Code2, Cpu, Database, Activity, Award, CheckCircle2, ChevronRight, Github, Linkedin, ExternalLink, Terminal } from "lucide-react";
import { SiPython, SiCplusplus, SiArduino, SiRaspberrypi, SiEspressif, SiJupyter, SiKicad } from "react-icons/si";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

function SectionHeading({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <motion.div 
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-100px" }}
      variants={fadeUp}
      className="mb-16 md:mb-24"
    >
      <div className="flex items-center gap-4 mb-4">
        <div className="h-[1px] w-12 bg-primary"></div>
        <h2 className="text-3xl md:text-5xl font-bold tracking-tight">{title}</h2>
      </div>
      {subtitle && <p className="text-muted-foreground font-mono text-sm md:text-base max-w-2xl">{subtitle}</p>}
    </motion.div>
  );
}

export function Hero() {
  return (
    <section id="home" className="min-h-[100dvh] flex items-center pt-20 pb-12 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-1/4 right-0 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-[400px] h-[400px] bg-primary/10 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
          className="max-w-4xl"
        >
          <motion.div variants={fadeUp} className="inline-block px-3 py-1 mb-6 border border-primary/30 bg-primary/5 text-primary font-mono text-sm font-medium">
            System Online. Initialization Complete.
          </motion.div>
          
          <motion.h1 variants={fadeUp} className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tighter mb-6 leading-tight">
            Atharv <br className="hidden md:block"/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/50">Mahesh Badase</span>
          </motion.h1>
          
          <motion.div variants={fadeUp} className="flex flex-col md:flex-row gap-4 md:items-center text-muted-foreground font-mono mb-10">
            <div className="flex items-center gap-2">
              <Cpu size={18} className="text-primary" />
              <span>Computer Science (IoT) Engineer</span>
            </div>
            <span className="hidden md:block text-border">|</span>
            <div className="flex items-center gap-2">
              <MapPin size={18} className="text-primary" />
              <span>Nagpur, Maharashtra, India</span>
            </div>
          </motion.div>
          
          <motion.p variants={fadeUp} className="text-lg md:text-xl text-foreground/80 max-w-2xl mb-12 leading-relaxed">
            I build the bridge between physical hardware and intelligent software. 
            Focused on efficient algorithms, clean Python code, and robust embedded systems.
          </motion.p>
          
          <motion.div variants={fadeUp} className="flex flex-wrap gap-4">
            <a 
              href="#projects" 
              className="px-8 py-4 bg-primary text-primary-foreground font-bold font-mono hover:bg-primary/90 transition-colors flex items-center gap-2 group"
            >
              View Projects
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a 
              href="mailto:atharv.badase22@gmail.com" 
              className="px-8 py-4 border border-border hover:border-primary text-foreground font-mono transition-colors flex items-center gap-2 hover:bg-primary/5"
            >
              <Mail size={18} />
              Contact
            </a>
            <a 
              href="https://www.linkedin.com/in/atharv-badase-910434410/" 
              target="_blank" 
              rel="noreferrer"
              className="px-4 py-4 border border-border hover:border-primary text-foreground transition-colors hover:bg-primary/5 flex items-center justify-center"
              aria-label="LinkedIn"
            >
              <Linkedin size={20} />
            </a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

export function About() {
  return (
    <section id="about" className="py-24 md:py-32 relative border-t border-border">
      <div className="container mx-auto px-6">
        <SectionHeading 
          title="About Me" 
          subtitle="Passionate about building efficient, scalable, and intelligent software solutions with real-world impact."
        />
        
        <div className="grid md:grid-cols-2 gap-12 lg:gap-24 items-start">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeUp}
            className="prose prose-invert prose-lg max-w-none text-muted-foreground leading-relaxed"
          >
            <p>
              I am a Computer Science Engineering student specializing in Internet of Things (IoT). My technical journey is driven by a deep fascination with how software can interact with and control the physical world.
            </p>
            <p>
              With hands-on experience in software development, data processing, and hardware integration, I approach problem-solving holistically. I don't just write code; I design systems. Whether it's crafting an elegant Python script, analyzing data sets, or programming microcontrollers, I focus on building solutions that are both robust and efficient.
            </p>
            <p>
              My foundation lies in core programming fundamentals, data structures, and algorithms, allowing me to adapt quickly to new technologies and scale my solutions effectively.
            </p>
          </motion.div>
          
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeUp}
            className="bg-card border border-border p-8 relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
            <Terminal className="text-primary mb-6" size={32} />
            <h3 className="text-xl font-bold mb-4 font-mono">Core Philosophy</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <ChevronRight className="text-primary shrink-0 mt-1" size={18} />
                <span className="text-muted-foreground"><strong className="text-foreground">Pragmatic Engineering:</strong> Choose the right tool for the job, not just the newest one.</span>
              </li>
              <li className="flex items-start gap-3">
                <ChevronRight className="text-primary shrink-0 mt-1" size={18} />
                <span className="text-muted-foreground"><strong className="text-foreground">End-to-End Ownership:</strong> From PCB layout to Python backend, understand the whole stack.</span>
              </li>
              <li className="flex items-start gap-3">
                <ChevronRight className="text-primary shrink-0 mt-1" size={18} />
                <span className="text-muted-foreground"><strong className="text-foreground">Continuous Iteration:</strong> Great systems are evolved, not just built.</span>
              </li>
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export function Skills() {
  const categories = [
    {
      title: "Programming",
      icon: <Code2 className="text-primary" size={24} />,
      items: [
        { name: "Python", icon: <SiPython /> },
        { name: "C/C++", icon: <SiCplusplus /> },
        { name: "Embedded C", icon: <Cpu /> },
        { name: "MATLAB", icon: <Activity /> }
      ]
    },
    {
      title: "Hardware & Embedded",
      icon: <Cpu className="text-primary" size={24} />,
      items: [
        { name: "ESP32", icon: <SiEspressif /> },
        { name: "Raspberry Pi", icon: <SiRaspberrypi /> },
        { name: "Arduino", icon: <SiArduino /> },
        { name: "Sensor Interfacing", icon: <Activity /> },
        { name: "PCB Layout (KiCad)", icon: <SiKicad /> },
        { name: "Soldering", icon: <Activity /> }
      ]
    },
    {
      title: "Tools & Platforms",
      icon: <Database className="text-primary" size={24} />,
      items: [
        { name: "Proteus", icon: <Activity /> },
        { name: "Tinkercad", icon: <Activity /> },
        { name: "MATLAB Simulink", icon: <Activity /> },
        { name: "Jupyter Notebook", icon: <SiJupyter /> },
        { name: "NLTK", icon: <Code2 /> }
      ]
    },
    {
      title: "Soft Skills",
      icon: <CheckCircle2 className="text-primary" size={24} />,
      items: [
        { name: "Analytical Thinking", icon: <Activity /> },
        { name: "Adaptability", icon: <Activity /> },
        { name: "Team Collaboration", icon: <Activity /> },
        { name: "Technical Documentation", icon: <Activity /> }
      ]
    }
  ];

  return (
    <section id="skills" className="py-24 md:py-32 relative border-t border-border bg-card/30">
      <div className="container mx-auto px-6">
        <SectionHeading 
          title="Technical Arsenal" 
          subtitle="A comprehensive toolkit spanning high-level software development to low-level hardware control."
        />
        
        <div className="grid md:grid-cols-2 gap-8">
          {categories.map((cat, i) => (
            <motion.div 
              key={cat.title}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              variants={fadeUp}
              className="border border-border bg-background p-8"
            >
              <div className="flex items-center gap-4 mb-8 pb-4 border-b border-border/50">
                {cat.icon}
                <h3 className="text-xl font-bold font-mono">{cat.title}</h3>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {cat.items.map(item => (
                  <div key={item.name} className="flex items-center gap-3 text-muted-foreground hover:text-foreground transition-colors">
                    <div className="text-primary/70">{item.icon}</div>
                    <span className="text-sm font-medium">{item.name}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Projects() {
  const projects = [
    {
      title: "Smart Student Monitoring System",
      tech: ["Python", "Data Structures", "File Handling"],
      description: "A comprehensive Python-based system designed for monitoring and managing student data efficiently. Features robust attendance tracking, in-depth performance analysis, and secure data storage.",
      impact: "Significantly improved data organization and simplified the student monitoring process by abstracting complex data handling into an intuitive interface.",
      type: "Software"
    },
    {
      title: "Wearable Health Monitor IoT Device",
      tech: ["Arduino", "MAX30100 Sensor", "Bluetooth", "C++"],
      description: "An Arduino-based wearable IoT device engineered to monitor vital health metrics including heart rate and SpO2 levels in real-time. Features Bluetooth integration for seamless data transmission to a companion mobile application.",
      impact: "Focused heavily on user experience and responsive design, integrating a basic payment simulation to demonstrate commercial viability.",
      type: "Hardware/IoT"
    }
  ];

  return (
    <section id="projects" className="py-24 md:py-32 relative border-t border-border">
      <div className="container mx-auto px-6">
        <SectionHeading 
          title="Featured Builds" 
          subtitle="Selected projects demonstrating problem-solving capabilities across software and hardware domains."
        />
        
        <div className="flex flex-col gap-12">
          {projects.map((project, i) => (
            <motion.div 
              key={project.title}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={fadeUp}
              className="group relative border border-border bg-card hover:border-primary/50 transition-colors duration-300"
            >
              <div className="flex flex-col md:flex-row">
                <div className="p-8 md:p-12 md:w-2/3 flex flex-col justify-center">
                  <div className="flex items-center gap-4 mb-4">
                    <span className="text-xs font-mono px-2 py-1 bg-primary/10 text-primary border border-primary/20 uppercase tracking-wider">
                      {project.type}
                    </span>
                  </div>
                  <h3 className="text-2xl md:text-3xl font-bold mb-4">{project.title}</h3>
                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    {project.description}
                  </p>
                  <div className="mb-8">
                    <h4 className="text-sm font-mono text-foreground mb-2">Impact & Architecture:</h4>
                    <p className="text-sm text-muted-foreground">{project.impact}</p>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-auto">
                    {project.tech.map(t => (
                      <span key={t} className="text-xs font-mono text-muted-foreground bg-background border border-border px-3 py-1">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="md:w-1/3 bg-background border-t md:border-t-0 md:border-l border-border p-8 flex items-center justify-center relative overflow-hidden">
                  {/* Abstract visualization of the project type */}
                  <div className="absolute inset-0 opacity-10 flex items-center justify-center group-hover:opacity-20 group-hover:scale-110 transition-all duration-700">
                    {project.type === "Software" ? (
                      <Code2 size={200} className="text-primary" />
                    ) : (
                      <Cpu size={200} className="text-primary" />
                    )}
                  </div>
                  <div className="relative z-10 w-16 h-16 rounded-full border border-primary/30 flex items-center justify-center bg-background group-hover:bg-primary group-hover:text-background transition-colors duration-300">
                    <ExternalLink size={24} />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function BackgroundList() {
  return (
    <section className="py-24 md:py-32 relative border-t border-border bg-card/30">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24">
          
          {/* Achievements */}
          <div id="achievements">
            <SectionHeading title="Achievements" />
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              variants={staggerContainer}
              className="space-y-6"
            >
              {[
                { title: "Robotics Club Coordinator", org: "GHRCEM", year: "2024–2025" },
                { title: "Volunteer", org: "IEEE Technical Workshop", year: "2025" },
                { title: "Scholarship for Academic Excellence", org: "Institutional", year: "2024" }
              ].map((item, i) => (
                <motion.div key={i} variants={fadeUp} className="flex gap-4 items-start p-6 border border-border bg-background hover:border-primary/30 transition-colors">
                  <Award className="text-primary shrink-0 mt-1" size={24} />
                  <div>
                    <h4 className="font-bold text-lg">{item.title}</h4>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground font-mono mt-2">
                      <span>{item.org}</span>
                      <span className="w-1 h-1 rounded-full bg-border"></span>
                      <span className="text-primary">{item.year}</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Certifications */}
          <div id="certifications">
            <SectionHeading title="Certifications" />
            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              variants={staggerContainer}
              className="space-y-6"
            >
              {[
                { title: "IoT Specialization", issuer: "Coursera", year: "2025", status: "Completed" },
                { title: "Python for Data Science", issuer: "NPTEL", year: "Ongoing", status: "In Progress" }
              ].map((item, i) => (
                <motion.div key={i} variants={fadeUp} className="flex gap-4 items-start p-6 border border-border bg-background hover:border-primary/30 transition-colors">
                  <Activity className="text-primary shrink-0 mt-1" size={24} />
                  <div className="w-full">
                    <div className="flex justify-between items-start gap-4 mb-2">
                      <h4 className="font-bold text-lg">{item.title}</h4>
                      <span className={`text-xs font-mono px-2 py-1 border ${item.status === 'Completed' ? 'border-primary/30 text-primary bg-primary/10' : 'border-border text-muted-foreground'}`}>
                        {item.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground font-mono">
                      <span>{item.issuer}</span>
                      {item.year !== 'Ongoing' && (
                        <>
                          <span className="w-1 h-1 rounded-full bg-border"></span>
                          <span className="text-primary">{item.year}</span>
                        </>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}

export function Contact() {
  return (
    <section id="contact" className="py-24 md:py-32 relative border-t border-border">
      <div className="container mx-auto px-6 max-w-4xl text-center">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          variants={fadeUp}
        >
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 border border-primary/30 text-primary mb-8">
            <Mail size={32} />
          </div>
          <h2 className="text-4xl md:text-6xl font-bold tracking-tight mb-6">Let's build something.</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-12">
            Currently open to new opportunities, collaborations, and technical challenges. 
            Whether you have a question or just want to say hi, my inbox is always open.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <a 
              href="mailto:atharv.badase22@gmail.com" 
              className="w-full sm:w-auto px-8 py-4 bg-primary text-primary-foreground font-bold font-mono hover:bg-primary/90 transition-colors flex items-center justify-center gap-2 group"
            >
              <Mail size={18} />
              atharv.badase22@gmail.com
            </a>
            <a 
              href="https://www.linkedin.com/in/atharv-badase-910434410/" 
              target="_blank" 
              rel="noreferrer"
              className="w-full sm:w-auto px-8 py-4 border border-border hover:border-primary text-foreground font-mono transition-colors flex items-center justify-center gap-2 hover:bg-primary/5"
            >
              <Linkedin size={18} />
              LinkedIn Profile
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="py-8 border-t border-border bg-card text-center">
      <div className="container mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-muted-foreground font-mono text-sm">
          <Terminal size={14} className="text-primary" />
          <span>© {new Date().getFullYear()} Atharv Mahesh Badase</span>
        </div>
        <div className="text-muted-foreground font-mono text-sm">
          Built with precision & purpose.
        </div>
      </div>
    </footer>
  );
}
